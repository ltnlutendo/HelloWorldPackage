# mypackage/setup.py
from setuptools import setup

setup(
    name='perf',
    version='0.1',
    packages=['perf'],
)
