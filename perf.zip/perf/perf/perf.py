# perf/perf.py

def SayHello():
    return "Hello!"

def HowAreYou():
    return "I'm doing well, thank you!"

def Goodbye():
    return "Goodbye!"
