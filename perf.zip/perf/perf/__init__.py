# perf/__init__.py

from perf.py import SayHello, HowAreYou, Goodbye

__all__ = ['SayHello', 'HowAreYou', 'Goodbye']
